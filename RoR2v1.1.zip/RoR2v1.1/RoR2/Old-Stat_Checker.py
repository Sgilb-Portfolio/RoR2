import pymem
import pymem.process
import time

# Attach to Risk of Rain 2 process
pm = pymem.Pymem('Risk of Rain 2.exe')

# Define base stats for all characters
characters = {
    "Acrid": {"base_hp": 160, "hp_scaling": 48, "base_hp_regen": 2.5, "hp_regen_scaling": 0.5, "base_damage": 15,
              "damage_scaling": 3.0, "base_speed": 7, "base_armor": 20},
    "Artificer": {"base_hp": 110, "hp_scaling": 33, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
                  "damage_scaling": 2.4, "base_speed": 7, "base_armor": 0},
    "Bandit": {"base_hp": 110, "hp_scaling": 33, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
               "damage_scaling": 2.4, "base_speed": 7, "base_armor": 0},
    "Captain": {"base_hp": 110, "hp_scaling": 33, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
                "damage_scaling": 2.4, "base_speed": 7, "base_armor": 0},
    "Commando": {"base_hp": 110, "hp_scaling": 33, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
                 "damage_scaling": 2.4, "base_speed": 7, "base_armor": 0},
    "Engineer": {"base_hp": 130, "hp_scaling": 39, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 14,
                 "damage_scaling": 2.8, "base_speed": 7, "base_armor": 0},
    "Huntress": {"base_hp": 90, "hp_scaling": 27, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
                 "damage_scaling": 2.4, "base_speed": 7, "base_armor": 0},
    "Loader": {"base_hp": 160, "hp_scaling": 48, "base_hp_regen": 2.5, "hp_regen_scaling": 0.5, "base_damage": 12,
               "damage_scaling": 2.4, "base_speed": 7, "base_armor": 20},
    "Mercenary": {"base_hp": 110, "hp_scaling": 33, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
                  "damage_scaling": 2.4, "base_speed": 7, "base_armor": 20},
    "MUL-T": {"base_hp": 200, "hp_scaling": 60, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 11,
              "damage_scaling": 2.2, "base_speed": 7, "base_armor": 12},
    "Railgunner": {"base_hp": 110, "hp_scaling": 33, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
                   "damage_scaling": 2.4, "base_speed": 7, "base_armor": 0},
    "REX": {"base_hp": 130, "hp_scaling": 39, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
            "damage_scaling": 2.4, "base_speed": 7, "base_armor": 20},
    "Void Fiend": {"base_hp": 110, "hp_scaling": 33, "base_hp_regen": 1, "hp_regen_scaling": 0.2, "base_damage": 12,
                   "damage_scaling": 2.4, "base_speed": 7, "base_armor": 0},
}
# Global variables
attack_speed_address = 0xff
movement_speed_address = 0xabc
crit_chance_address = 0xccc
bleed_chance_address = 0xacc
health_regen_address = 0xddd
armor_address = 0xad
player_level_address = 0xf

"""
# White Items
armor_piercing_rounds_address = 0xF
backup_magazine_address = 0xFF
bison_steak_address = 0xf
bundle_of_fireworks_address = 0xff
bustling_fungus_address = 0xc
cautious_slug_address = 0xc
crowbar_address = 0xef
delicate_watch_address = 0xee
energy_drink_address = 0xFF
focus_crystal_address = 0xef
gasoline_address = 0xf
lens_makers_glasses_address = 0xFFF
medkit_address = 0xf
mocha_address = 0xff
oddly_shaped_opal_address = 0xff
pauls_goat_hoof_address = 0xfff
personal_shield_generator_address = 0xff
power_elixir_address = 0xf
repulsion_armor_plate_address = 0xff
soldiers_syringe_address = 0xfff
sticky_bomb_address = 0xf
stun_grenade_address = 0xf
topaz_brooch_address = 0xf
tougher_times_address = 0xf
tri_tip_dagger_address = 0xfff
warbanner_address = 0xaa

# Green Items
atg_missile_mk_1_address = 0xff
bandolier_address = 0xff
berzerkers_pauldron_address = 0xabc
chronobauble_address = 0xff
death_mark_address = 0xee
fuel_cell_address = 0xff
harvesters_scythe_address = 0xab
hopoo_feather_address = 0x00FFABD1
hunters_harpoon_address = 0xff
ignition_tank_address = 0xff
infusion_address = 0xa
item_scrap_green_address = 0xfff
kjaros_band_address = 0xff
leeching_seed_address = 0x00FFABD4
lepton_daisy_address = 0xfff
old_guillotine_address = 0xfff
old_war_stealthkit_address = 0xaaa
predatory_instincts_address = 0xee
razorwire_address = 0xff
red_whip_address = 0xff
regenerating_scrap_address = 0xff
rose_buckler_address = 0xff
runalds_band_address = 0xfff
shipping_request_form_address = 0xff
shuriken_address = 0xabc
squid_polyp_address = 0xfff
ukulele_address = 0xbb
war_horn_address = 0xbbb
wax_quail_address = 0xff
will_o_the_wisp_address = 0xf


# Red Items
rejuvenation_rack_address = 0xee

# Yellow Items
irradiant_pearl_address = 0xeee
pearl_address = 0xab
shatterspleen_address = 0xff

# Lunar/Blue Items
shaped_glass_address = 0xff

# Void Items

# Equipment
gnarled_woodsprite_address = 0xff
"""


# Function to read item counts from memory
def read_item_count(address):
    return pm.read_int(address)


# Function to prompt the user for a character and validate input
def select_character():
    while True:
        print("Select a character from the following list:")
        for character in characters.keys():
            print(character)

        selected_character = input("Enter the character name: ").strip()

        if selected_character in characters:
            return selected_character
        else:
            print("Character not found. Please enter a valid character name.\n")


# Main script execution
selected_character = select_character()
base_stats = characters[selected_character]

"""
# Calculate current stats based on items and scaling
def calculate_current_armor():

def calculate_current_movement_speed():


def calculate_current_hp(level):
    return base_stats['base_hp'] + (base_stats['hp_scaling'] * level)


def calculate_current_hp_regen(level):
    return base_stats['base_hp_regen'] + (base_stats['hp_regen_scaling'] * level)


def calculate_current_damage(level):
    return base_stats['base_damage'] + (base_stats['damage_scaling'] * level)


def calculate_healing_per_damage(leeching_seed_count):
    healing_per_damage = leeching_seed_count * 1  # Each Leeching Seed heals 1 HP per hit
    return healing_per_damage * damage_dealt


def calculate_healing_per_hit(medkit_count):
    medkit_healing = medkit_count * 10  # Each Medkit heals 10 HP after being hit
    return medkit_healing


def calculate_bleed_chance(dagger_count):
    return .1 * dagger_count

def calculate_crit_chance(glasses_count, scythe_count, instincts_count):
    crit_chance_return = (.1 * glasses_count) + (.05 * scythe_count) + (.05 * instincts_count)
    return crit_chance_return
"""

while True:

    # Reading item counts from memory
    """
    leeching_seed_count = read_item_count(leeching_seed_address)
    medkit_count = read_item_count(medkit_address)
    feather_count = read_item_count(hopoo_feather_address)
    dagger_count = read_item_count(tri_tip_dagger_address)
    glasses_count = read_item_count(lens_makers_glasses_address)
    scythe_count = read_item_count(harvesters_scythe_address)
    instincts_count = read_item_count(predatory_instincts_address)
    """

    attack_speed = read_item_count(attack_speed_address)
    movement_speed = read_item_count(movement_speed_address)
    crit_chance = read_item_count(crit_chance_address)
    bleed_chance = read_item_count(bleed_chance_address)
    health_regen = read_item_count(health_regen_address)
    armor = read_item_count(armor_address)
    player_level = read_item_count(player_level_address)


    """
    # Calculating stats
    current_hp = calculate_current_hp(player_level)
    current_hp_regen = calculate_current_hp_regen(player_level)
    current_damage = calculate_current_damage(player_level)
    healing_per_damage = calculate_healing_per_damage(leeching_seed_count)
    healing_per_hit = calculate_healing_per_hit(medkit_count)
    bleed_chance = calculate_bleed_chance(dagger_count)
    crit_chance = calculate_crit_chance(glasses_count, scythe_count, instincts_count)
    jumps = 1 + feather_count  # Start with 1 jump, each Feather adds 1 more
    """

    # Displaying stats
    print(f"{selected_character} Stats:")
    print(f"Attack Speed: {attack_speed} | Movement Speed: {movement_speed} m/s | Crit Chance: {crit_chance}%")
    print(f"Bleed Chance: {bleed_chance}% | Health Regen: {health_regen} HP/s")
    print(f"Armor: {armor}")

    # Sleep for a short duration before updating again
    time.sleep(1)
